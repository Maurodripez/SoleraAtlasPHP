-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.24-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.2.0.6576
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para soleraatlas
CREATE DATABASE IF NOT EXISTS `soleraatlas` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `soleraatlas`;

-- Volcando estructura para tabla soleraatlas.citas
CREATE TABLE IF NOT EXISTS `citas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(450) DEFAULT NULL,
  `start` varchar(45) DEFAULT NULL,
  `end` varchar(45) DEFAULT NULL,
  `infoAdicional` varchar(45) DEFAULT NULL,
  `asesor` varchar(45) DEFAULT NULL,
  `color` varchar(45) DEFAULT NULL,
  `fkCitas` int(11) DEFAULT NULL,
  `siniestro` varchar(450) DEFAULT NULL,
  `operador` varchar(450) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla soleraatlas.citas: ~5 rows (aproximadamente)
DELETE FROM `citas`;
INSERT INTO `citas` (`id`, `title`, `start`, `end`, `infoAdicional`, `asesor`, `color`, `fkCitas`, `siniestro`, `operador`) VALUES
	(14, 'marina', '2022-12-20 09:00:00', '2022-12-20 10:00:00', 'werwer', 'Alexis castillo', '#ff0000', 837, '42172278', 'Mauricio Rodriguez'),
	(15, 'mar', '2022-12-06 09:00:00', '2022-12-06 10:00:00', 'awdsd', 'Alexis castillo', '#ff0000', 842, '42164643', 'Mauricio Rodriguez'),
	(16, '', '2022-12-05 09:00:00', '2022-12-05 10:00:00', '', 'Alexis castillo', '#ff0000', 843, '042186005-001', 'Mauricio Rodriguez'),
	(17, '', '2022-12-27 09:00:00', '2022-12-27 10:00:00', '', 'Alexis castillo', '#ff0000', 844, '042183705-001', 'Mauricio Rodriguez'),
	(19, 'marina', '2022-12-27 09:00:00', '2022-12-27 10:00:00', '', 'Alexis castillo', '#ff0000', 841, '042129318-003', 'Mauricio Rodriguez'),
	(20, 'qwe', '2022-12-28 09:00:00', '2022-12-28 10:00:00', 'qwe', 'Alexis castillo', '#ff0000', 839, '42129149', 'Mauricio Rodriguez');

-- Volcando estructura para tabla soleraatlas.usuariostemporales
CREATE TABLE IF NOT EXISTS `usuariostemporales` (
  `idusuariosTemporales` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(45) DEFAULT NULL,
  `contrasena` varchar(45) DEFAULT NULL,
  `fechaDeCreacion` datetime DEFAULT NULL,
  PRIMARY KEY (`idusuariosTemporales`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla soleraatlas.usuariostemporales: ~2 rows (aproximadamente)
DELETE FROM `usuariostemporales`;
INSERT INTO `usuariostemporales` (`idusuariosTemporales`, `usuario`, `contrasena`, `fechaDeCreacion`) VALUES
	(17, 'hola', 'td3ttaf01u', '2022-12-20 08:08:31'),
	(30, 'SIN42129149', 'bhpsfdfn03', '2022-12-20 08:24:55'),
	(34, 'SIN042129318-003', '0sst54uk10', '2022-12-21 09:01:47');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
