package com.example.demo.models;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

@Entity
@Table(name = "usuarios")
@ToString @EqualsAndHashCode
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Getter @Setter @Column(name ="id")
    private Long id;

    @Getter @Setter @Column(name ="usuario")
    private String usuario;

    @Getter @Setter @Column(name ="contrasena")
    private String contrasena;

    @Getter @Setter @Column(name ="privilegios")
    private String privilegios;

    @Getter @Setter @Column(name ="nombrereal")
    private String nombrereal;

    @Getter @Setter @Column(name ="turno")
    private String turno;

    @Getter @Setter @Column(name ="disponible")
    private String disponible;

    @Getter @Setter @Column(name ="telefono")
    private String telefono;

    @Getter @Setter @Column(name ="email")
    private String email;

    @Getter @Setter @Column(name ="equipo")
    private String equipo;

}
