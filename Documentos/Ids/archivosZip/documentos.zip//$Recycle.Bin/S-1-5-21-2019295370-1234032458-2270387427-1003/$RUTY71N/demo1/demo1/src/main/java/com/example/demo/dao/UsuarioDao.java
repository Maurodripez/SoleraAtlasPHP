package com.example.demo.dao;

import com.example.demo.models.Usuario;

import java.util.List;

public interface UsuarioDao {
    List<Usuario> getUsuarios();
    List<Usuario> updateUsuarios();

    void eliminar(Long id);

    void addUsuario(Usuario usuario);

    boolean verificarSesion(Usuario usuario);
}
