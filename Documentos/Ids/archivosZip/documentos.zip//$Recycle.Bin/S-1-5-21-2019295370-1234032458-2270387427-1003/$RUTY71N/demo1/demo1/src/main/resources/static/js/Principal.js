$(document).ready(function () {
  $( "#oprimir" ).click(function() {
    var event = {
      title: "evento",
      description: "Lorem ipsum 1...",
      start: yyyy + "-" + mm + "-01",
      color: "#3A87AD",
      textColor: "#ffffff",
    };

    $("#calendar").fullCalendar("renderEvent", event, true);
  });
  function addZero(i) {
    if (i < 10) {
      i = "0" + i;
    }
    return i;
  }

  var hoy = new Date();
  var dd = hoy.getDate();
  if (dd < 10) {
    dd = "0" + dd;
  }

  if (mm < 10) {
    mm = "0" + mm;
  }

  var mm = hoy.getMonth() + 1;
  var yyyy = hoy.getFullYear();

  dd = addZero(dd);
  mm = addZero(mm);

  $(document).ready(function () {
    $("#calendar").fullCalendar({
      header: {
        left: "prev,next",
        center: "title,addEventButton",
        right: "month,agendaWeek,agendaDay",
      },
      customButtons: {
        addEventButton: {
          text: "add event...",
          click: function () {
            var dateStr = prompt("nueva fecha");
            var date = moment(dateStr);

            if (date.isValid()) {
              $("#calendar").fullCalendar("renderEvent", {
                title: "dynamic event",
                start: date,
                allDay: true,
              });
              alert("Great. Now, update your database...");
            } else {
              alert("Invalid date.");
            }
          },
        },
      },
      defaultDate: yyyy + "-" + mm + "-" + dd,
      buttonIcons: true, // show the prev/next text
      weekNumbers: false,
      editable: true,
      eventLimit: true, // allow "more" link when too many events
      events: [
        {
          title: "All Day Event",
          description: "Lorem ipsum 1...",
          start: yyyy + "-" + mm + "-01",
          color: "#3A87AD",
          textColor: "#ffffff",
        },
        {
          title: "Long Event",
          description: "Lorem ipsum 2...",
          start: yyyy + "-" + mm + "-07",
          end: yyyy + "-" + mm + "-10",
          color: "#e74032",
          textColor: "#ffffff",
        },
        {
          title: "Repeating Event",
          description: "Lorem ipsum 3...",
          start: yyyy + "-" + mm + "-09T16:00:00",
          color: "#e74032",
          textColor: "#ffffff",
        },
        {
          title: "Repeating Event",
          description: "Lorem ipsum 4...",
          start: yyyy + "-" + mm + "-16T16:00:00",
          color: "#e74032",
          textColor: "#ffffff",
        },
        {
          title: "Conference",
          description: "Lorem ipsum 5...",
          start: yyyy + "-" + mm + "-11",
          end: yyyy + "-" + mm + "-13",
          color: "#3A87AD",
          textColor: "#ffffff",
        },
        {
          title: "Meeting",
          description: "Lorem ipsum 6...",
          start: yyyy + "-" + mm + "-12T10:30:00",
          end: yyyy + "-" + mm + "-12T12:30:00",
          color: "#3A87AD",
          textColor: "#ffffff",
        },
        {
          title: "Lunch",
          description: "Lorem ipsum 7...",
          start: yyyy + "-" + mm + "-12T12:00:00",
          color: "#3A87AD",
          textColor: "#ffffff",
        },
        {
          title: "Meeting",
          description: "Lorem ipsum 8...",
          start: yyyy + "-" + mm + "-12T14:30:00",
          color: "#3A87AD",
          textColor: "#ffffff",
        },
        {
          title: "Happy Hour",
          description: "Lorem ipsum 9...",
          start: yyyy + "-" + mm + "-12T17:30:00",
          color: "#3A87AD",
          textColor: "#ffffff",
        },
        {
          title: "Dinner",
          description: "Lorem ipsum 10...",
          start: yyyy + "-" + mm + "-12T20:00:00",
          color: "#3A87AD",
          textColor: "#ffffff",
        },
        {
          title: "Birthday Party",
          description: "Lorem ipsum 11...",
          start: yyyy + "-" + mm + "-13T07:00:00",
          color: "#3A87AD",
          textColor: "#ffffff",
        },
        {
          title: "Event with link",
          description: "Lorem ipsum 12...",
          url: "http://www.jose-aguilar.com/",
          start: yyyy + "-" + mm + "-28",
          color: "#3A87AD",
          textColor: "#ffffff",
        },
      ],
      eventClick: function (calEvent, jsEvent, view) {
        $("#event-title").text(calEvent.title);
        $("#event-description").html(calEvent.description);
        $("#modal-event").modal();
      },
    });
  });
});
async function agregarCaso(){
    const rawResponse = await fetch('Usuarios', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({a: 1, b: 'Textual content'})
    });
    const content = await rawResponse.json();
  
    console.log(content);
  
}