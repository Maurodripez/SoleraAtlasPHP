async function Login() {
  let datos = {};
  datos.email = document.getElementById("txtCorreo").value;
  datos.contrasena = document.getElementById("txtPassword").value;
  const request = await fetch("api/login", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify(datos),
  });
  const respuesta = await request.json();
}
