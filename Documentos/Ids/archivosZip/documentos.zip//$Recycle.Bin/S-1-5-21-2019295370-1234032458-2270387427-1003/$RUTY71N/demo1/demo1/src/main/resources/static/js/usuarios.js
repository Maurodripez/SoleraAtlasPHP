// Call the dataTables jQuery plugin
$(document).ready(function () {
  mostrarUsuarios();
  $("#usuarios").DataTable();
});
async function mostrarUsuarios() {
  const request = await fetch("api/usuarios", {
    method: "get",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
  });
  const usuarios = await request.json();
  console.log(usuarios);
  let tablaPrueba = document.querySelector("#tablaPrueba");
  for (let tablaUsuarios of usuarios) {
    let usuarioTabla = `
    <tr>
    <td><a href='#' onclick="eliminarUsuarios(${tablaUsuarios.id})" class='btn btn-danger btn-circle'><i class='fas fa-trash'></i></a></td>
      <td>${tablaUsuarios.usuario}</td>
      <td>${tablaUsuarios.contrasena}</td>
      <td>${tablaUsuarios.privilegios}</td>
      <td>${tablaUsuarios.nombrereal}</td>
      <td>${tablaUsuarios.turno}</td>
      <td>${tablaUsuarios.disponible}</td>
      <td>${tablaUsuarios.telefono}</td>
      <td>${tablaUsuarios.email}</td>
      <td>${tablaUsuarios.equipo}</td>
    </tr>
  </tbody>`;
    tablaPrueba.innerHTML += usuarioTabla;
  }
}
async function eliminarUsuarios(id) {
  const request = await fetch("api/usuarios/"+id, {
    method: "DELETE",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
  });
  location.reload();
}
async function agregarUsuario(){
  const request = await fetch("api/usuarios", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
  });
}