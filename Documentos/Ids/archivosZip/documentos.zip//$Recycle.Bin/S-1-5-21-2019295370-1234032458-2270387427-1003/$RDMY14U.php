<?php
require("../models/FuncionesSQL.php");
$accion = $_POST['accion'];
if ($accion == "MostrarUsuarios") {
    $sql = "select usuario, nombre, perfil, turno, equipo from usuarios";
    ConsultasSelectCualquiera($sql, "../models/Conexion.php", "data");
}
