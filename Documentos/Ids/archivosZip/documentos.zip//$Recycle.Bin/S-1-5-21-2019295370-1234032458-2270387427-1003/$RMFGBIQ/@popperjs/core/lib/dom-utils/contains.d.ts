export default function contains(parent: Element, child: Element): boolean;
