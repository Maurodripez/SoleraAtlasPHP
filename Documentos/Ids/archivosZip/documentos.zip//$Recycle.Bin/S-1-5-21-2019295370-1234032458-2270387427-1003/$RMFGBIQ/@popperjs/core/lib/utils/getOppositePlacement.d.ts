import type { Placement } from "../enums";
export default function getOppositePlacement(placement: Placement): Placement;
