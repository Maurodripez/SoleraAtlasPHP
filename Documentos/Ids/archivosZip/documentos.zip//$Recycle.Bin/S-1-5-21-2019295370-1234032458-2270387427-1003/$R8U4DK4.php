<?php
$accion = $_POST['accion'];
echo $accion;
